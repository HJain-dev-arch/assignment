package com.example.learnings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningsApplicationTests {

	@Test
	void contextLoads() {
	}

}
