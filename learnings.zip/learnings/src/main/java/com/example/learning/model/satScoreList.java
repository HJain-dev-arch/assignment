package com.example.learning.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="satScoreList")
public class satScoreList {
	
	@Id
	@Column(unique=true)
	private String name;
	
	@OneToOne(targetEntity = addressStudent.class, cascade = CascadeType.ALL)
	private addressStudent address;
	
	private int satScore;
	private String passed;
	
	public satScoreList() {
	}
	
	public satScoreList(String name, addressStudent address, int satScore, String passed) {
		this.name = name;
		this.address = address;
		this.satScore = satScore;
		this.passed = passed;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public addressStudent getAddress() {
		return address;
	}
	public void setAdress(addressStudent address) {
		this.address = address;
	}
	public int getSatScore() {
		return satScore;
	}
	public void setSatScore(int satScore) {
		this.satScore = satScore;
	}
	public String getPassed() {
		return passed;
	}
	public void setPassed(String passed) {
		this.passed = passed;
	}

	@Override
	public String toString() {
		return "satScore [name=" + name + ", address=" + address + ", satScore=" + satScore + ", passed=" + passed
				+ "]";
	}
}

