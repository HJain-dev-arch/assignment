package com.example.learning.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.learning.model.addressStudent;

@Repository
public interface addressRepository extends JpaRepository<addressStudent,Long>{

}
