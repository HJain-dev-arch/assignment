package com.example.learning;

import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.learning.model.addressStudent;
import com.google.gson.Gson;
import com.example.learning.model.satScoreList;
import com.example.learning.repository.addressRepository;
import com.example.learning.repository.scoreRepository;

@SpringBootApplication
@EnableJpaRepositories
public class LearningsApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(LearningsApplication.class, args);
	}
	
		@Autowired
		private addressRepository addressRepo;
		
		@Autowired
		private scoreRepository scoreRepo;
		
		 @Override
		 public void run(String... args) throws Exception {
			 
			Scanner sc = new Scanner(System.in);
			while(true)
			{
				satScoreList score;
				addressStudent addressStudents = new addressStudent();
				Gson gson = new Gson(); 
				System.out.println("Enter the choice");
				int choice = sc.nextInt();
				try {
					switch(choice)
					{
					case 1:
						System.out.println("Enter the name");
						String name = sc.next();
						if(scoreRepo.findByName(name)==null)
						{
							System.out.println("Enter the city");
							String city = sc.next();
							System.out.println("Enter the country");
							String country = sc.next();
							System.out.println("Enter the pincode");
							String pincode = sc.next();
							System.out.println("Enter the satScore");
							int satScore = sc.nextInt();
							String passed = satScore < 30? "failed":"passed";
							addressStudents.setCity(city);
							addressStudents.setCountry(country);
							addressStudents.setPincode(pincode);
							addressRepo.save(addressStudents);
							try {
								//addressRepo.save(addressStudents);
								score = new satScoreList(name,addressStudents,satScore,passed);
								scoreRepo.save(score);
								//scoreRepo.save(score);
							}catch(Exception e)
							{
								e.printStackTrace();
							}
						}
						else
						{
							System.out.println("Name exists");
						}
					break;
					case 2:
						Iterable<satScoreList> list = scoreRepo.findAll();
						System.out.println(gson.toJson(list));
					break;
					case 3:
						System.out.println("Enter the name for rank");
						name = sc.next();
						if(scoreRepo.findByName(name)!=null)
						{
							Iterable<satScoreList> sort = scoreRepo.findAll(Sort.by("satScore").descending());
							int rank=0;
							for(satScoreList score1:sort)
							{
								rank++;
								if(score1.getName().equals(name))
								{
									System.out.println(rank);
									break;
								}
							}
						}
					break;
					case 4:
						System.out.println("Enter the score to be updated");
						int updatedScore = sc.nextInt();
						System.out.println("Enter the name fo which it is to be updated");
						name = sc.next();
						if(scoreRepo.findByName(name)!=null)
						{
							score = scoreRepo.findByName(name);
							score.setSatScore(updatedScore);
							score.setPassed(updatedScore < 30? "failed":"passed");
							System.out.println(score.toString());
						}
					break;
					case 5:
						System.out.println("Enter the name fo which it is to be deleted");
						name = sc.next();
						try
						{
							if(scoreRepo.findByName(name)!=null)
							{
								scoreRepo.deleteByName(name);
								System.out.println("Deleted successfully");
							}
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					break;
					default:
						break;
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		 }
}
